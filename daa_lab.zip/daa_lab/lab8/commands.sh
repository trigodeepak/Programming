gcc my_longest_common_subsequence.c
./a.out
gcc matrix_multiplication.c
./a.out