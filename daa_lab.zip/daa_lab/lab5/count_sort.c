#include<stdio.h>
#include<stdlib.h>
void count_sort(int *a,int n)
{
    int i,j,b[n],k=10;
    static int c[10];//we are making assumption that elements are 0 to 9 only i.e. fixing range
    for(j=0;j<n;j++)
	{
		c[a[j]]=c[a[j]]+1;
	}
	for(i=1;i<k;i++)
	{
		c[i]=c[i]+c[i-1];
	}
	for(j=n-1;j>=0;j--)
	{
		b[c[a[j]]-1]=a[j];
		c[a[j]]=c[a[j]]-1;
	}
	for(i=0;i<n;i++)
        a[i]=b[i];
}
int main()
{
	int n=50,i;
	FILE *fp;
    fp=fopen("inputcount.txt","r");
    fscanf(fp,"%d",&n);
    int *a=(int *)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        fscanf(fp,"%d",&a[i]);
// 	for(i=0;i<n;i++)
// 	{
// 		a[i]=rand()%10;
// 		printf("%d ",a[i]);
// 	}
	count_sort(a,n);

	printf("\nThe sorted array is\n");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	return 0;
}