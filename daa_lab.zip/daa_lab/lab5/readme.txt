This lab is based on different types of sorts.These are 
1.Heap sort
2.counting sort 
3.Bucket sort 
4.Radix sort
I have used an arrray input in these sorting programs because input format is not same for all these techniques, I have printed output on the screen
to have the file input we can add the following code to a program and take input from the file
FILE *fp;
int n;
fp=fopen("input.txt",r);
fscanf(fp,"%d",&n);
int *a=(int *)malloc(n*sizeof(int));
for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    