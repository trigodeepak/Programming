gcc heap_sort.c
./a.out
gcc count_sort.c
./a.out
gcc bucket_sort_without_struct.c
./a.out
gcc bucketsortusingstruct.c
./a.out
gcc radix_sort.c
./a.out