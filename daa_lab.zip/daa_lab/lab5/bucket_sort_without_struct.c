#include<stdio.h>
#include<stdlib.h>

void bucket_sort(float a[],int n)
{
	float b[10];
	int x,i;
	for(i=0;i<n;i++)
	{
		x=a[i]*10;
		b[x]=a[i];
	}
	for(i=0;i<n;i++)
	{
		a[i]=b[i];
	}
}
int main()
{
	int n=10,i;
	//this can only be used for inputs which store in different buckets
//	FILE *fp;
//    fp=fopen("inputbucket.txt","r");
//    fscanf(fp,"%d",&n);
//    float *a=(float *)malloc(n*sizeof(float));
//    for(i=0;i<n;i++)
//        fscanf(fp,"%d",&a[i]);
	float a[10]={0.25,.67,.83,.74,.08,.99,.57,.43,.33,.17};
	bucket_sort(a,n);
	for(i=0;i<n;i++)
	{
		printf("%.2f\n",a[i]);
	}
	return 0;
}