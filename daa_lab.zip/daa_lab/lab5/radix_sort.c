#include<stdio.h>
#include<stdlib.h>
void count_sort(int a[],int n,int exp)
{   int count[10]={0};
    int  k=10,i;
    int b[n];
	for(i=0;i<n;i++)
        count[(a[i]/exp)%10]=count[(a[i]/exp)%10]+1;
	for (i=1; i<k; i++)
		count[i] += count[i-1];
	for (i = n-1;i>=0; i--)
	{   b[count[(a[i]/exp)%10]-1]=a[i];
	    count[(a[i]/exp)%10]--;
	}
	for (i = 0; i<n; ++i)
		a[i]=b[i];

}
void radix_sort(int a[],int n,int max)
{   int exp;
    for(exp=1;max/exp>0;exp*=10)
        count_sort(a,n,exp);
}

int main()
{   int i,max=0,n=8;
    //scanf("%d",&n);
    // int a[8]={170, 45, 75, 90, 802, 24, 2, 66};
    // for(i=0;i<n;i++)
    // {   //scanf("%d",&a[i]);
    //     if(a[i]>max)
    //         max=a[i];
    // }
    FILE *fp;
    fp=fopen("input.txt","r");
    fscanf(fp,"%d",&n);
    int *a=(int *)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
    {fscanf(fp,"%d",&a[i]);
        if(a[i]>max)
            max=a[i];}
    radix_sort(a,n,max);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
    return 0;
}