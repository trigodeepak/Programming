#include<stdio.h>
#include<stdlib.h>
void swap(int *a,int *b)
{
	int t=*a;	*a=*b;	*b=t;
}
void max_heapify(int a[],int n,int i)
{
	int lar=i;
	int l=2*i+1,r=2*i+2;
	if(l<n && a[l]>a[i])
		lar=l;
	if(r<n && a[r]>a[lar])
		lar=r;
	if(lar!=i)
	{
		swap(&a[i],&a[lar]);
		max_heapify(a,n,lar);
    }

}
void build_max_heap(int a[],int n)
{
	int i;
	for(i=n/2-1;i>=0;i--)
		max_heapify(a,n,i);
}
void heap_sort(int a[],int n)
{
	build_max_heap(a,n);
	int i;
	for(i=n-1;i>=0;i--)
	{
		swap(&a[0],&a[i]);
		max_heapify(a,i,0);
	}
}
int main()
{
	int n=5,i;
	FILE *fp;
    fp=fopen("input.txt","r");
    fscanf(fp,"%d",&n);
    int *a=(int *)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
        fscanf(fp,"%d",&a[i]);
	heap_sort(a,n);

	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
}