Objective_1:To analyse the complexity of quick sort when we have different pivot positions
    I have created 4 programs for quicksort i.e. for beginning, end , middle and random pivot for quicksort.
    Procedure : first we can run makefile.c to create a input file then we apply all four sorts on the file.(Go to command.txt and run it all)
    Result : By my experiment I have made 7 input files and applied all quicksort on each file
            It is clearly seen that taking middle element as pivot has least no. of counts for comparision part.
            Average results are end = 22, beginning =19, mid=18, random=20 
