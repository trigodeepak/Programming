#include<stdio.h>
int main(){
    FILE *fp;
    fp=fopen("input.txt","w");
    int test,n,a,i,j;
    test=15;
    for(i=0;i<test;i++){
        n=rand()%25;
        fprintf(fp,"%d\n",n);
        for(j=0;j<n;j++){
            a=rand()%50;
            fprintf(fp,"%d\n",a);
        }
    }   
    
}
