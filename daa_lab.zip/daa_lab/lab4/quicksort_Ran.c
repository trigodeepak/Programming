#include<stdio.h>
unsigned long count_Ran=0;
unsigned long test=0; 
//quicksort when piovot is at random
void quicksort_Ran(int a[],int p,int r){
    if(p<r){
        int q;
        q=partition_Ran(a,p,r);
        quicksort_Ran(a,p,q-1);
        quicksort_Ran(a,q+1,r);            
    }
}
int partition_Ran(int a[],int p,int r){
    int x,i,t,j;
    //swapping making a random element end
    int m=rand()%(r-p);
    t=a[p+m];
    a[p+m]=a[r];
    a[r]=t;
    
    x=a[r];
    i=p-1;
    for(j=p;j<=r-1;j++){
        count_Ran++;
        if(a[j]<=x){
            i=i+1;
            t=a[i];
            a[i]=a[j];
            a[j]=t;
        }
    }
    t=a[i+1];
    a[i+1]=a[r];
    a[r]=t;
    return i+1;  
}

int main()
{   
    FILE *fp;
    fp=fopen("input.txt","r");
    int n,i;
    while(!feof(fp)){
        fscanf(fp,"%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            fscanf(fp,"%d",&a[i]);
        }
        quicksort_Ran(a,0,n-1);
        test++;                
    }
    printf("The average number of step with quicksort pivot as random are %lu",count_Ran/test);
    return 0;
}
