#include<stdio.h>
unsigned long count_Mid=0;
unsigned long test=0; 
//quicksort when piovot is at Middle
void quicksort_Mid(int a[],int p,int r){
    if(p<r){
        int q;
        q=partition_Mid(a,p,r);
        quicksort_Mid(a,p,q-1);
        quicksort_Mid(a,q+1,r);            
    }
}
int partition_Mid(int a[],int p,int r){
    int x,i,t,j;
    //swapping making Middle element end
    t=a[(p+r)/2];
    a[(p+r)/2]=a[r];
    a[r]=t;
    x=a[r];
    i=p-1;
    for(j=p;j<=r-1;j++){
        count_Mid++;
        if(a[j]<=x){
            i=i+1;
            t=a[i];
            a[i]=a[j];
            a[j]=t;
        }
    }
    t=a[i+1];
    a[i+1]=a[r];
    a[r]=t;
    return i+1;  
}

int main()
{   
    FILE *fp;
    fp=fopen("input.txt","r");
    int n,i;
    while(!feof(fp)){
        fscanf(fp,"%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            fscanf(fp,"%d",&a[i]);
        }
        quicksort_Mid(a,0,n-1);
        test++;                
    }
    printf("The average number of step with quicksort pivot as mid are %lu",count_Mid/test);
    return 0;
}
