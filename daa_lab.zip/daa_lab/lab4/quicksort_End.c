#include<stdio.h>
unsigned long count_End=0;
unsigned long test=0; 
//quicksort when piovot is at Endinning
void quicksort_End(int a[],int p,int r){
    if(p<r){
        int q;
        q=partition_End(a,p,r);
        quicksort_End(a,p,q-1);
        quicksort_End(a,q+1,r);            
    }
}
int partition_End(int a[],int p,int r){
    int x,i,t,j;
    x=a[r];
    i=p-1;
    for(j=p;j<=r-1;j++){
        count_End++;
        if(a[j]<=x){
            i=i+1;
            t=a[i];
            a[i]=a[j];
            a[j]=t;
        }
    }
    t=a[i+1];
    a[i+1]=a[r];
    a[r]=t;
    return i+1;  
}

int main()
{   
    FILE *fp;
    fp=fopen("input.txt","r");
    int n,i;
    while(!feof(fp)){
        fscanf(fp,"%d",&n);
        int a[n];
        for(i=0;i<n;i++){
            fscanf(fp,"%d",&a[i]);
        }
        quicksort_End(a,0,n-1);
        test++;                
    }
    printf("The average number of step with quicksort pivot as end are %lu",count_End/test);
    return 0;
}
