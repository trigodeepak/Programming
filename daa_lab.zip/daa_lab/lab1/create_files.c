//To create 25 files in a directory
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char *argv[])
{	char fn[50]="a.txt";
	int i,j,n,a;
	FILE *fp1;
	for(i=0;i<25;i++){
	fp1=fopen(fn,"w");
	n=rand()%20+4;
	fprintf(fp1,"%d \n",n);
	for(j=0;j<n;j++){
		a=rand()%100+1;
		fprintf(fp1,"%d \n",a);}	
 	fclose(fp1);
 	fn[0]++;	
    	}	
}

