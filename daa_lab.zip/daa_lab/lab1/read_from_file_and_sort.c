#include<stdio.h>
#include<stdlib.h>
int main()
{
 FILE *fp;
 fp=fopen("input.txt","r");
 int n;
 fscanf(fp,"%d",&n);
 int *a,i=0,j,t;
 a=(int*)malloc(n*sizeof(int));
 while(i<n){
    fscanf(fp,"%d",a+i);
    i++;
 }
 for(i=0;i<n-1;i++)
 {
    for(j=0;j<n-i-1;j++)
    {
        if(*(a+j)>*(a+j+1))
        {   t=*(a+j+1);
            *(a+j+1)=*(a+j);
            *(a+j)=t;
        }
    }
 }
 for(i=0;i<n;i++){
    printf("%d ",*(a+i));
 }
 fclose(fp);
 fp=fopen("output.txt","w");
 i=0;
 while(i<n){
    fprintf(fp,"%d \n",*(a+i));
    i++;
 }
}
