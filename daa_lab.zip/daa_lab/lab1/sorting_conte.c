#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void sort(int *a,int n){
	int i,j,t;
	 for(i=0;i<n-1;i++)
 	{
    	for(j=0;j<n-i-1;j++)
    	{
        if(*(a+j)>*(a+j+1))
        {   t=*(a+j+1);
            *(a+j+1)=*(a+j);
            *(a+j)=t;
        }
    	}
 	}
}
int main(int argc,char *argv[])
{	char str[100]="ls ";
	char *fl=" > inp.tx";
	strcat(str,argv[1]); 
	strcat(str,fl);
	system(str);
	char fname[100];
	FILE *fp,*fp1;
	int k;
	fp1=fopen("inp.tx","r");
	for(k=0;k<25;k++){
		fscanf(fp1,"%s",fname);
		if((strstr(fname,".txt")||strstr(fname,".dat"))) {
		char fdir[100]="";
     		strcat(fdir,argv[1]);
    		strcat(fdir,fname);
    		printf("%s",fdir);    		
    		fp=fopen(fdir,"r");
    		//read and sort array
    		int n,*a,i=0;
    		fscanf(fp,"%d",&n);
		a=(int*)malloc(n*sizeof(int));
		while(i<n){
    		fscanf(fp,"%d",a+i);
    		i++;
 		}
 		sort(a,n);
 		fclose(fp);
 		fp=fopen(fname,"w");
 		for(i=0;i<n;i++)
 		{	fprintf(fp,"%d \n",*(a+i));
 		}
 		fclose(fp);
 		
    		}}	
}

