gcc master_method -lm
./a.out
gcc binary_tree.c
./a.out
gcc binary_tree_traversals.c
./a.out