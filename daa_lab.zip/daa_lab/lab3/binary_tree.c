//program to create a binary tree and find out the following
//depth,total nodes,and number of leaf nodes
#include<stdio.h>
#include<stdlib.h>
struct t
{   int value;
    struct t *l;
    struct t *r;
};
void insert_node(int temp,struct t *root)
{
    struct t *newnode=(struct t*)malloc(sizeof(struct t));
    newnode->value=temp;
    newnode->l=newnode->r=NULL;
    if(root==NULL)
    {
        root = newnode;
    }
    else if(root->value <= temp)
    {   if(root->r!=NULL)
        insert_node(temp,root->r);
        else
        root->r=newnode;
    }
    else
    {   if(root->l!=NULL)
        insert_node(temp,root->l);
        else
        root->l=newnode;
    }
}
int max_depth(struct t *root)
{
    if(root==NULL)
        return 0;
    else
    {   int lsize=max_depth(root->l);
        int rsize=max_depth(root->r);
        if(lsize>rsize)
            return (lsize+1);
        else
            return (rsize+1);
    }
}
int total_nodes(struct t *root)
{
    static int total=1;
    if(root==NULL)
        return 0;
    else
    {
        if(root->r!=NULL)
        {   total++;
            total_nodes(root->r);
        }
        if(root->l!=NULL)
        {   total++;
            total_nodes(root->l);
        }
    }
    return total;
}
int leaf_nodes(struct t *root)
{
    static int leaf=1;
    if(root==NULL)
        return 0;
    else
    {   if(root->r==NULL&&root->l==NULL)
        leaf++;
        else
        {   leaf_nodes(root->l);
            leaf_nodes(root->r);
        }
    }
    return leaf;
}
int main()
{
    int a[]={5,10,12,3,2,20};
    int n=6,i,j;
    struct t *root=(struct t *)malloc(sizeof(struct t));
    root->value=a[0];  root->l=root->r=NULL;
    for(i=1;i<n;i++)
    {   insert_node(a[i],root);
    }
    printf("\nDepth of tree = %d",max_depth(root));
    printf("\nTotal nodes = %d",total_nodes(root));
    printf("\nTotal leaf nodes = %d",leaf_nodes(root));
    return 0;
}
