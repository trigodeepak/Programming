//program to implement master method
#include<stdio.h>
#include<math.h>
int main()
{
    printf("Enter value of a, b and c (c is f(n)=n^c) :\n");
    float a,b,c,d,f;
    scanf("%d %d %d",&a,&b,&c);
    d=(log(a)/log(b));
    if(d>c)
    {
        printf("The complexity of the given algorithm is O(n^%.0f)",d);
    }else if(d<c)
    {
        f=a/pow(b,c);
        if(f<1)printf("The complexity of the given algorithm is O(n^%.0f)",c);
        else printf("The complexity can't be determined in this case because there is a gap between bounds of case 2 and case 3");
    }
    else
    {
        printf("The complexity of the given algorithm is O(n^%.0f*log(n))",c);
    }
    return 0;
}
