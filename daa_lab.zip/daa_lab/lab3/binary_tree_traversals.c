//program to create a binary tree and traverse
//traversing in all three ways inorder,postorder and preorder
#include<stdio.h>
#include<stdlib.h>
struct t
{   int value;
    struct t *l;
    struct t *r;
};
void insert_node(int temp,struct t *root)
{
    struct t *newnode=(struct t*)malloc(sizeof(struct t));
    newnode->value=temp;
    newnode->l=newnode->r=NULL;
    if(root==NULL)
    {
        root = newnode;
    }
    else if(root->value <= temp)
    {   if(root->r!=NULL)
        insert_node(temp,root->r);
        else
        root->r=newnode;
    }
    else
    {   if(root->l!=NULL)
        insert_node(temp,root->l);
        else
        root->l=newnode;
    }
}
void post_order(struct t *root)
{   if(root==NULL)
        return;
    post_order(root->l);
    post_order(root->r);
    printf("%d ",root->value);
}
void in_order(struct t *root)
{   if(root==NULL)
        return;
    in_order(root->l);
    printf("%d ",root->value);
    in_order(root->r);

}
void pre_order(struct t *root)
{   if(root==NULL)
        return;
    printf("%d ",root->value);
    pre_order(root->l);
    pre_order(root->r);
}

int main()
{
    int a[]={5,10,12,3,2,20};
    int n=6,i,j;
    struct t *root=(struct t *)malloc(sizeof(struct t));
    root->value=a[0];  root->l=root->r=NULL;
    for(i=1;i<n;i++)
    {   insert_node(a[i],root);
    }
    printf("\nInorder Traversal : ");    in_order(root);
    printf("\nPreorder Traversal : ");   pre_order(root);
    printf("\nPostorder Traversal : ");  post_order(root);
    return 0;
}
