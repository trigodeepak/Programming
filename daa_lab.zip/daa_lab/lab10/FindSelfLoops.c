#include<stdio.h>
#include<stdlib.h>
//Program to count number of self loops
int main()
{
      FILE *fp;
      int n=5,i,j,count=0;
      fp = fopen("input_list.txt","r");
      fscanf(fp,"%d",&n);
      int **a = (int **)malloc(n * sizeof(int *));
        for (i=0; i<n; i++)
            a[i] = (int *)malloc(n * sizeof(int));
        for(i=0;i<n;i++)
            {for(j=0;j<n;j++)
            {fscanf(fp,"%d",&a[i][j]);
            printf("%d ",a[i][j]);}
                printf("\n");}
//      int a[5][5]= {{0,1,0,0,1},{1,0,1,1,0},{0,1,0,0,1},{0,1,1,0,1},{1,1,0,1,0}};
	for(i=0;i<n;i++)
            if(a[i][i]==1)
                count++;
                printf("\n Number of self connected nodes are : %d",count);
return 0;
}
