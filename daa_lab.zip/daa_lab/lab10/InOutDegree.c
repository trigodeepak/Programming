#include<stdio.h>
#include<stdlib.h>
//Program to print in and out degree of all the elements
int main()
{
      FILE *fp;
      int n=5,i,j,count=0;
      fp = fopen("input_list.txt","r");
      fscanf(fp,"%d",&n);
      int **a = (int **)malloc(n * sizeof(int *));
        for (i=0; i<n; i++)
            a[i] = (int *)malloc(n * sizeof(int));
        for(i=0;i<n;i++)
            {for(j=0;j<n;j++)
            {fscanf(fp,"%d",&a[i][j]);
            printf("%d ",a[i][j]);}
                printf("\n");}
//      int a[5][5]= {{0,1,0,0,1},{1,0,1,1,0},{0,1,0,0,1},{0,1,1,0,1},{1,1,0,1,0}};
    int i_deg[n],o_deg[n];
    for(i=0;i<n;i++)
           {i_deg[i]=0;
            o_deg[i]=0;
           }
	for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if(a[i][j]==1)
                {i_deg[i]++;
                o_deg[j]++;}
    for(i=0;i<n;i++)
            printf("Element : %d Indegree : %d Outdegree : %d \n",i,i_deg[i],o_deg[i]);
return 0;
}
