#include<stdio.h>
#include<stdlib.h>
//Program to print number of isolated nodes
int main()
{
      FILE *fp;
      int n=5,i,j,count=0,f=0;
      fp = fopen("input_list.txt","r");
      fscanf(fp,"%d",&n);
      int **a = (int **)malloc(n * sizeof(int *));
        for (i=0; i<n; i++)
            a[i] = (int *)malloc(n * sizeof(int));
        for(i=0;i<n;i++)
            {for(j=0;j<n;j++)
            {fscanf(fp,"%d",&a[i][j]);
            printf("%d ",a[i][j]);}
                printf("\n");}
//      int a[5][5]= {{0,1,0,0,1},{1,0,1,1,0},{0,1,0,0,1},{0,1,1,0,1},{1,1,0,1,0}};
	for(i=0;i<n;i++){
            f=0;
        for(j=0;j<n;j++)
            if(a[i][j]==1)
                {f=1;
                break;}
        if(f==0)
            count++;    }
        printf("The number of isolated nodes are : %d",count);
return 0;
}
