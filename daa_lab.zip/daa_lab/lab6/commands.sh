gcc inorder_iterative.c
./a.out
gcc preorder_iterative.c
./a.out
gcc postorder_iterative.c
./a.out
