#include<stdio.h>
#include<stdlib.h>
typedef struct node
{   int value;
    struct node *l;
    struct node *r;
}Node;
void insert_node(int temp,struct node *root)
{
    struct node *newnode=(struct node*)malloc(sizeof(struct node));
    newnode->value=temp;
    newnode->l=newnode->r=NULL;
    if(root==NULL)
    {
        root = newnode;
    }
    else if(root->value <= temp)
    {   if(root->r!=NULL)
        insert_node(temp,root->r);
        else
        root->r=newnode;
    }
    else
    {   if(root->l!=NULL)
        insert_node(temp,root->l);
        else
        root->l=newnode;
    }
}
#define STACK_SIZE 10

typedef struct stack{
        int top;
        Node *items[STACK_SIZE];
}stack;

void push(stack *ms, Node *item){
   if(ms->top < STACK_SIZE-1){
       ms->items[++(ms->top)] = item;
   }
   else {
       printf("Stack is full\n");
   }
}

Node * pop (stack *ms){
   if(ms->top > -1 ){
       return ms->items[(ms->top)--];
   }
   else{
       printf("Stack is empty\n");
   }
}
Node * peek(stack ms){
  if(ms.top < 0){
      printf("Stack empty\n");
      return 0;
   }
   return ms.items[ms.top];
}
int isEmpty(stack ms){
   if(ms.top < 0) return 1;
   else return 0;
}

void preorderTraversalWithoutRecursion(Node *root){
    stack ms;
    ms.top = -1;

    if(!root) return ;

    Node *currentNode = NULL;
    /* Step 1 : Start with root */
    push(&ms,root);

    while(!isEmpty(ms)){
        /* Step 5 : Pop the node */
        currentNode = pop(&ms);
        /* Step 2 : Print the node */
        printf("%d  ", currentNode->value);
        /* Step 3: Push right child first */
        if(currentNode->r){
            push(&ms, currentNode->r);
        }
        /* Step 4: Push left child */
        if(currentNode->l){
            push(&ms, currentNode->l);
        }
    }
}

int main()
{
    FILE *fp;
    fp=fopen("tree_input.txt","r");
    int n,i,j;
    fscanf(fp,"%d",&n);
    int *a= malloc(n*sizeof(struct node));
    for(i=0;i<n;i++)
        fscanf(fp,"%d",&a[i]);
    struct node *root=(struct node *)malloc(sizeof(struct node));
    root->value=a[0];  root->l=root->r=NULL;
    for(i=1;i<n;i++)
    {   insert_node(a[i],root);
    }
    printf("Postorder traversal without recursion : "); preorderTraversalWithoutRecursion(root);
    return 0;
}
