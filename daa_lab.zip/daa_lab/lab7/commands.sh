gcc order_statistics.c
./a.out