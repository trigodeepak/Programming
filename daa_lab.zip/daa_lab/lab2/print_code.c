#include<stdio.h>
int main(){
    FILE *fp;
    fp=fopen(__FILE__,"r");
    char s;
    s=fgetc(fp);
    printf("%c",s);
    while(s!=EOF){
    s=fgetc(fp);
    printf("%c",s);}
    fclose(fp);
}
