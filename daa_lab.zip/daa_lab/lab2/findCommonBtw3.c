#include<stdio.h>
#include<stdlib.h>
void findcommon(int a[],int b[],int c[],int n,int m,int p){
    int i,j,k;
    i=j=k=0;    
    while(i<n&&j<m&&k<p){
    	if(a[i]==b[j]&&b[j]==c[k])
    	{
    		printf("%d",a[i]);
    		i++;j++;k++;
    	}
    	else if(a[i]<b[j])
    		i++;
    		
    	else if(b[j]<c[k])
    		j++;
    	else
    		k++;
    }
}
void main()
{   FILE *fp;
    fp=fopen("input.txt","r");
    int m,n,p;
    int i;
    //taking input from file
    fscanf(fp,"%d",&n);
    int *a=(int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
    {   fscanf(fp,"%d",a+i);}
    fscanf(fp,"%d",&m);
    int *b=(int*)malloc(m*sizeof(int));
    for(i=0;i<m;i++)
    {   fscanf(fp,"%d",b+i);}
    fscanf(fp,"%d",&p);
    int *c=(int*)malloc(p*sizeof(int));
    for(i=0;i<p;i++)
    {   fscanf(fp,"%d",c+i);}
    //as all three array are sorted
    findcommon(a,b,c,n,m,p);
    fclose(fp);
}

