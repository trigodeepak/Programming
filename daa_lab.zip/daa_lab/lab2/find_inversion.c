#include<stdio.h>
#include<stdlib.h>
void find_inv(int a[],int n){
    int i,j;
    for(i=0;i<n;i++){
        for(j=i;j<n;j++){
        if(a[i]>a[j]){
        printf("i=%d j=%d\n",i,j);}}}
    }
void main()
{   FILE *fp;
    fp=fopen("input4.txt","r");
    int n;
    int i;
    //taking input from file
    fscanf(fp,"%d",&n);
    int *a=(int*)malloc(n*sizeof(int));
    for(i=0;i<n;i++)
    {   fscanf(fp,"%d",a+i);}
    //calling the function
    find_inv(a,n);
    fclose(fp);
}
