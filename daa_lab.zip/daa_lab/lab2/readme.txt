Questions
1. To find common between 3 arrays using complexity O(n).
2. To print the lines of the same program we are executing.
3. To find inverse elements in an array from a file.
4. To print hello world on screen without using any semicolon.

